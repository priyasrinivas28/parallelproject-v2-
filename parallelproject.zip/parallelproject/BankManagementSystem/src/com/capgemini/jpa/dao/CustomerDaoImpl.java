package com.capgemini.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.CustomerException;
import com.capgemini.jpa.utility.JPAUtil;

public class CustomerDaoImpl implements ICustomerDAO {
	private EntityManager entityManager=null;
	/*HashMap<Long, Customer> customermap = new HashMap<Long,Customer>();
	Map<Long, StringBuffer> transaction = new HashMap<Long, StringBuffer>();*/
	Customer customer=new Customer();
	@Override
	public Customer addNewCustomer(Customer customer) throws CustomerException {
		// TODO Auto-generated method stub
		 /*customermap.put(accno,c);
		 System.out.println(customermap);*/
		try{
			entityManager=JPAUtil.getEntityManager();
			//entityManager =Persistence.createEntityManagerFactory("JPACRUDProject").createEntityManager();
			entityManager.getTransaction().begin();

			Transaction transaction = new Transaction();
			transaction.setBankAccountNumber(customer);
			transaction.setTransactionAmount(customer.getBalance());
			transaction.setTransactionType("DEPOSIT");
			entityManager.persist(transaction);
			entityManager.persist(customer);
			entityManager.getTransaction().commit();			
		}catch(PersistenceException e) {
			e.printStackTrace();

			throw new CustomerException(e.getMessage());
		}finally {
			entityManager.close();
		}
		return customer;
	}

	@Override
	public Customer showBalance(Integer accountNumber, Integer accountPin)
			throws CustomerException {
		// TODO Auto-generated method stub
		/*for(Customer customermap:customermap.values()) {
			if(customermap.getAccno()==accno) {
				System.out.println("The account details are"+customermap);*/
	
		try{
			/*boolean flag= isValid(accountNumber, accountPin);
			if(flag){
			try{*/
			entityManager=JPAUtil.getEntityManager();
			
			//entityManager =Persistence.createEntityManagerFactory("JPACRUDProject").createEntityManager
			
			 customer  = entityManager.find(Customer.class, accountNumber);
			 System.out.println(customer);
			 System.out.println(customer.getAccountNumber());
			 System.out.println(customer.getAccountPin());
			 System.out.println(customer.getBalance());
			 System.out.println(accountPin);
			 System.out.println(accountNumber);
			 
			 if(customer.getAccountNumber().equals(accountNumber) && customer.getAccountPin().equals( accountPin))			 {
			/*if(customer==null){
				System.out.println("xtys");
			}
			else if((customer.getAccountNumber()==accountNumber)&&(customer.getAccountPin()==accountPin)){
			//System.out.println("THE BALANCE PRESENT IN YOUR ACCOUNT IS :"+customer.getBalance());
				return customer;
			 }
			else{
				System.out.println("priya");*/
			//}
			 
				
			System.out.println("fdhfdgtd");
			 }else
			 {
				 System.out.println("sdfdyg");
			 }
			
		}catch(PersistenceException e) {
			e.printStackTrace();

			throw new CustomerException(e.getMessage());
		}finally {
			entityManager.close();
		}
		return customer;
	}
/*public boolean isValid(Integer accountNumber,Integer accountPin){
	boolean flag=false;
	Customer cust= new Customer();
	entityManager.getTransaction().begin();
	cust  = entityManager.find(Customer.class, accountNumber);
	if((cust.getAccountNumber()==accountNumber)&&(cust.getAccountPin()==accountPin)){
		flag=true;
		System.out.println(flag);
		return flag;
		
	}
	
	return flag;
}*/
	@Override
	public Customer deposit(Integer accountNumber, Double depositAmount)
			throws CustomerException {
		
		try{

			entityManager=JPAUtil.getEntityManager();
			//entityManager =Persistence.createEntityManagerFactory("JPACRUDProject").createEntityManager
			entityManager.getTransaction().begin();
			customer   = entityManager.find(Customer.class, accountNumber);
			Double balance1=customer.getBalance();
			//System.out.println("THE BALANCE PRESENT IN YOUR ACCOUNT IS :"+cust.getBalance());
			Double deposit=balance1+depositAmount;
			customer.setBalance(deposit);
			entityManager.merge(customer);
			Transaction transaction = new Transaction();
			transaction.setTransactionAmount(depositAmount);
			transaction.setTransactionType("DEPOSIT");
			transaction.setBankAccountNumber(customer);
			entityManager.persist(transaction);
	
			entityManager.getTransaction().commit();	
			//System.out.println("Account Balance is: " + cust.getBalance());
		}catch(PersistenceException e) {
			e.printStackTrace();

			throw new CustomerException(e.getMessage());
		}finally {
			entityManager.close();
		}
		
		return customer;
	}

	@Override
	public Customer withdraw(Integer accountNumber, Integer pin,
			Double withdrawAmount) throws CustomerException {
		// TODO Auto-generated method stub
		try{

			entityManager=JPAUtil.getEntityManager();
			//entityManager =Persistence.createEntityManagerFactory("JPACRUDProject").createEntityManager
			entityManager.getTransaction().begin();
			customer  = entityManager.find(Customer.class, accountNumber);
			Double balance1=customer.getBalance();
			//System.out.println("THE BALANCE PRESENT IN YOUR ACCOUNT IS :"+cust.getBalance());
			Double withdraw=balance1-withdrawAmount;
			customer.setBalance(withdraw);
			entityManager.merge(customer);
			Transaction transaction = new Transaction();
			transaction.setTransactionAmount(withdrawAmount);
			transaction.setTransactionType("WITHDRAW");
			transaction.setBankAccountNumber(customer);
			entityManager.persist(transaction);
			entityManager.getTransaction().commit();	
			System.out.println("Account Balance is: " + customer.getBalance());
		}catch(PersistenceException e) {
			e.printStackTrace();

			throw new CustomerException(e.getMessage());
		}finally {
			entityManager.close();
		}
		return customer;
	}

	@Override
	public Customer fundTransfer(Integer accountNumber, Integer pin,
			Integer transferAccountNumber, Double transferAmount)
			throws CustomerException {
		// TODO Auto-generated method stub
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			//Employee employee= entityManager.find(Employee.class, accno);
			 Customer cust1f = entityManager.find(Customer.class, accountNumber);
		 customer = entityManager.find(Customer.class, transferAccountNumber);
			Double balance_from = cust1f.getBalance();
			balance_from = balance_from-transferAmount;
			cust1f.setBalance(balance_from);
			entityManager.merge(cust1f);
			Double balance_to = customer.getBalance();
			//ADDING THE DETAILS TO THE TRANSACTION_DETAILS TABLE FROM THE ACCOUNT
			Transaction transaction1f = new Transaction();
			transaction1f.setTransactionAmount(balance_from);
			transaction1f.setTransactionType("Fund Transfer(Sent)");
			transaction1f.setBankAccountNumber(cust1f);
			entityManager.persist(transaction1f);
			
			balance_to += transferAmount;
			
			customer.setBalance(balance_to);

			
			entityManager.merge(customer);
			
			
			//ADDING THE DETAILS TO THE TRANSACTION_DETAILS TABLE TO THE ACCOUNT
			Transaction transaction2t = new Transaction();
			transaction2t.setTransactionAmount(balance_to);
			transaction2t.setTransactionType("Fund Transfer(Recieved)");
			transaction2t.setBankAccountNumber(customer);
			entityManager.persist(transaction2t);

			entityManager.getTransaction().commit();	

			/*System.out.println("Account Balance(FROM ACCOUNT) is: " + cust1f.getBalance());
			System.out.println("Account Balance(TO ACCOUNT) is: " + cust2t.getBalance());*/



		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerException(e.getMessage());
		}finally {
			entityManager.close();
		}
		return customer;

	}

	@Override
	public List<Transaction> printTransactions(Integer accountNumber) 
			throws CustomerException {
		// TODO Auto-generated method stub
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
	    Query query= entityManager.createNativeQuery("select * from bank_details where acc_no=?",Transaction.class);
		query.setParameter(1,accountNumber);
		
	    List<Transaction> transList = query.getResultList();
	   // System.out.println(transList);
	    return transList;
		}catch(PersistenceException e) {
			e.printStackTrace();
			

			throw new CustomerException(e.getMessage());
		}finally {
			entityManager.close();
			
		}
	}

	

}
