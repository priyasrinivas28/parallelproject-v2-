package com.capgemini.jpa.dao;



import java.util.List;

import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.CustomerException;

public interface ICustomerDAO {
	public abstract Customer addNewCustomer(Customer customer) throws CustomerException;
	public abstract Customer showBalance(Integer accountNumber,Integer accountPin) throws CustomerException;
	public abstract Customer deposit(Integer accountNumber, Double depositAmount) throws CustomerException;
	public abstract Customer withdraw (Integer accountNumber,Integer pin,Double withdrawAmount) throws CustomerException;
	public abstract Customer fundTransfer(Integer accountNumber,Integer pin,Integer transferAccountNumber,Double transferAmount)throws CustomerException;

	public List<Transaction> printTransactions(Integer accountNumber) throws CustomerException;
	
}
