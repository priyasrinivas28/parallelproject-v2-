package com.capgemini.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="bank_details")
public class Transaction {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer SerialNumber;
	private Double transactionAmount;
	private String transactionType;
	@ManyToOne
	@JoinColumn(name="acc_no")
	private Customer bankAccountNumber;
	public Integer getSerialNumber() {
		return SerialNumber;
	}
	public void setSerialNumber(Integer serialNumber) {
		SerialNumber = serialNumber;
	}
	public Double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(Double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Customer getBankAccountNumber() {
		return bankAccountNumber;
	}
	public void setBankAccountNumber(Customer bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}
	@Override
	public String toString() {
		return "Transaction [transactionAmount=" + transactionAmount
				+ ", transactionType=" + transactionType + "]";
	}
	
	
	
	
	
	
	
}
