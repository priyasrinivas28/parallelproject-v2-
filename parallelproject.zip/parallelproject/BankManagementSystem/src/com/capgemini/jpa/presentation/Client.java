package com.capgemini.jpa.presentation;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.CustomerException;
import com.capgemini.jpa.service.CustomerServiceImpl;
import com.capgemini.jpa.service.ICustomerService;

public class Client {
	static Scanner sc=new Scanner(System.in);
	Client client=new Client();
	static CustomerServiceImpl serviceImpl= new CustomerServiceImpl();
	static Random rand = new Random();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		while(true){

			System.out.println("WELCOME TO PAYMENT WALLENT APPLICATION");
			System.out.println("******************************************************");
			System.out.println("1.CREATE ACCOUNT");
			System.out.println("2.SHOW BALANCE");
			System.out.println("3.DEPOSIT");
			System.out.println("4.WITHDRAW");
			System.out.println("5.FUND TRANSFER");
			System.out.println("6.PRINT TRANSACTION");
			System.out.println("7.EXIT");
			System.out.println("********************************************************");
			System.out.println("ENTER YOUR CHOICE");

			int ch=sc.nextInt();

			switch(ch){
			case 1:
				Customer customer=new Customer();
				do{
				System.out.println("ENTER YOUR NAME");
				customer.setName(sc.next());
				}while(!serviceImpl.validateName(customer.getName()));
				do{
				System.out.println("ENTER YOUR PHONE NUMBER");
				customer.setPhoneNumber(sc.next());
				}while(!serviceImpl.validatePhonenumber(customer.getPhoneNumber()));
				do{
				System.out.println("ENTER YOUR AGE");
				customer.setAge(sc.nextInt());
				}while(!serviceImpl.validateAge(customer));
				do{
				System.out.println("ENTER YOUR ADDRESS");
				customer.setAddress(sc.next());
				}while(!serviceImpl.validateAddress(customer.getAddress()));
				do{
				System.out.println("ENTER YOUR BALANCE");
				customer.setBalance(sc.nextDouble());
				}while(!serviceImpl.validateBalance(customer));
			
				System.out.println("ENTER YOUR EMAILID");
				customer.setEmailId(sc.next());
				
				//Long accountNumber = 10000+rand.nextLong(456); 
			
				Integer accountNumber = 100000 + rand.nextInt(1000000);
				customer.setAccountNumber(accountNumber);
				System.out.println(accountNumber);
				Integer accountPin = 1000 + rand.nextInt(9000);
				customer.setAccountPin(accountPin);
				System.out.println(accountPin);

				
				addNewCustomer(customer);

				System.out.println(customer);





				break;
			case 2:
			
			
				Customer customer2=new Customer();
				System.out.println("ENTER THE ACCOUNT NUMBER");
				
				Integer accountNumber1=sc.nextInt();
				
		
				System.out.println("ENTER THE ACCOUNT PIN");
				Integer accountPin1=sc.nextInt();
		
			
				getshowBalance(accountNumber1,accountPin1);
			

				break;
			case 3:
				Customer customer3=new Customer();
				System.out.println("ENTER THE ACCOUNT NUMBER");
				Integer accountNumber3=sc.nextInt();
				System.out.println("ENTER THE AMOUNT TO BE DEPOSITED");
				Double depositAmount1=sc.nextDouble();
				getDeposit(accountNumber3,depositAmount1);

				break;
			case 4:
				Customer customer4=new Customer();
				System.out.println("ENTER THE ACCOUNT NUMBER");
				Integer accountNumber4=sc.nextInt();
				System.out.println("ENTER THE ACCOUNT PIN");
				Integer pin1=sc.nextInt();
				System.out.println("ENTER THE AMOUNT TO BE WITHDRAWED");
				Double withdrawAmount1=sc.nextDouble();
				getWithdraw(accountNumber4,pin1,withdrawAmount1);
				break;
			case 5:
				Customer customer5=new Customer();
				System.out.println("ENTER THE ACCOUNT NUMBER");
				Integer accountNumber5=sc.nextInt();
				System.out.println("ENTER THE ACCOUNT PIN");
				Integer pin2=sc.nextInt();
				System.out.println("ENTER THE ACCOUNT NUMBER OF THE MONEY TO BE TRANSFERED");
				Integer transferAccountNumber=sc.nextInt();
				System.out.println("ENTER THE AMOUNT TO BE TRANSFERRED");
				Double transferAmount=sc.nextDouble();
				getTransfer(accountNumber5,pin2,transferAccountNumber,transferAmount);
				break;
			case 6:
				System.out.println("ENTER THE ACCOUNT NUMBER TO GET THE DETAILS");
				Integer accountNumber7 = sc.nextInt();
				getprintTransaction(accountNumber7);
				break;
			case 7:
				System.exit(0);
				break;
			default:
				break;
			}

		}
	}

	private static void getprintTransaction(Integer accountNumber) {
		// TODO Auto-generated method stub
		List<Transaction> translist;
		try{

		translist=	serviceImpl.printTransactions(accountNumber);
		System.out.println("THE DETAILS OF YOUR TRANSACTIONS ARE :"+"\n"+translist);

		}
		catch(CustomerException e){
			System.out.println("CUSTOMER NOT FOUND"+e.getMessage());

		}
	}

	private static void getTransfer(Integer accountNumber, Integer pin,
			Integer transferAccountNumber, Double transferAmount) {
		// TODO Auto-generated method stub
		Customer cust=new Customer();
		try{

			cust=serviceImpl.fundTransfer(accountNumber, pin, transferAccountNumber, transferAmount);
			if(cust!=null){
				System.out.println("THE BALANCE PRESENT IN YOUR ACCOUNT AFTER TRANSFER IS:"+cust.getBalance());
			}
			else{
				System.out.println("INVALID CREDENTIALS");
			}
		}
		catch(CustomerException e){
			System.out.println("CUSTOMER NOT FOUND"+e.getMessage());

		}
	}

	private static void getWithdraw(Integer accountNumber, Integer pin,
			Double withdrawAmount) {
		// TODO Auto-generated method stub
		Customer cust=new Customer();
		try{

			cust=serviceImpl.withdraw(accountNumber,pin,withdrawAmount);
			if(cust!=null){
				System.out.println("THE BALANCE PRESENT IN YOUR ACCOUNT AFTER THE WITHDRAW IS :"+cust.getBalance());
			}
			else{
				System.out.println("INVALID CREDENTIALS");
			}
		}
		catch(CustomerException e){
			System.out.println("CUSTOMER NOT FOUND"+e.getMessage());

		}

	}

	private static void getDeposit(Integer accountNumber,Double depositAmount) {
		// TODO Auto-generated method stub
Customer cust=new Customer();
		try{

			cust=serviceImpl.deposit(accountNumber,depositAmount);
			if(cust!=null){
				System.out.println("THE BALANCE PRESENT IN YOUR ACCOUNT AFTER DEPOSIT IS"+cust.getBalance());
			}
			else{
				System.out.println("INVALID CREDENTIALS");
			}

		}
		catch(CustomerException e){
			System.out.println("CUSTOMER NOT FOUND"+e.getMessage());

		}
	}

	private static void getshowBalance(Integer accountNumber, Integer accountPin) {
		Customer cust=new Customer();
		try{

			 cust=serviceImpl.showBalance(accountNumber,accountPin);
			 if(cust!=null){
			System.out.println("THE BALANCE PRESENT IN YOUR ACCOUNT IS:"+cust.getBalance());

			 }

else{
	System.out.println("ENTER VALID ACCOUNT NO ND PIN");
}
			
		}
		catch(CustomerException e){
			System.out.println("CUSTOMER NOT FOUND"+e.getMessage());

		}

	}

	

	private static void addNewCustomer(Customer customer) {
		// TODO Auto-generated method stub
Customer cust=new Customer();
		try{

			cust=serviceImpl.addNewCustomer(customer);
			if(cust!=null){
				System.out.println("THE CUSTOMER DETAILS ARE:"+cust);
			}
			else{
				System.out.println("ENTER VALID ACCOUNT DETAILS");
			}

		}
		catch(CustomerException e){
			System.out.println("CUSTOMER NOT FOUND"+e.getMessage());

		}


	}

}
