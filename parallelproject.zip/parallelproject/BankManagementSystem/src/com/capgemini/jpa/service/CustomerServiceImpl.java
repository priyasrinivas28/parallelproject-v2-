package com.capgemini.jpa.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.jpa.dao.CustomerDaoImpl;
import com.capgemini.jpa.dao.ICustomerDAO;
import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.CustomerException;

public class CustomerServiceImpl implements ICustomerService{
	static ICustomerDAO customerDAO=new CustomerDaoImpl();
	@Override
	public Customer addNewCustomer(Customer customer) throws CustomerException {
		// TODO Auto-generated method stub
	return	customerDAO.addNewCustomer(customer);
	}

	@Override
	public Customer showBalance(Integer accountNumber, Integer accountPin)
			throws CustomerException {
		// TODO Auto-generated method stub
	return	customerDAO.showBalance(accountNumber, accountPin);

		
	}

	@Override
	public Customer deposit(Integer accountNumber, Double depositAmount)
			throws CustomerException {
		// TODO Auto-generated method stub
		return customerDAO.deposit(accountNumber, depositAmount);
	}

	@Override
	public Customer withdraw(Integer accountNumber, Integer pin,
			Double withdrawAmount) throws CustomerException {
		// TODO Auto-generated method stub
	return	customerDAO.withdraw(accountNumber, pin, withdrawAmount);
	}

	@Override
	public Customer fundTransfer(Integer accountNumber, Integer pin,
			Integer transferAccountNumber, Double transferAmount)
			throws CustomerException {
		// TODO Auto-generated method stub
		return customerDAO.fundTransfer(accountNumber, pin, transferAccountNumber, transferAmount);
	}

	

	@Override
	public List<Transaction> printTransactions(Integer accountNumber)
			throws CustomerException {
		// TODO Auto-generated method stub
		return customerDAO.printTransactions(accountNumber);
	}

	public boolean validateName(String name) {
		boolean flag=false;
		String s=name; 
	    Pattern pattern = Pattern.compile(new String ("^[a-zA-Z]{3,15}$"));
	    /*# Start of the line
	    [a-z0-9_-]	     # Match characters and symbols in the list, a-z, 0-9, underscore, hyphen
	               {3,15}  # Length at least 3 characters and maximum length of 15 
	  $                    # End of the line*/
	    Matcher matcher = pattern.matcher(s);
	    if(matcher.matches())
	    {
	         flag=true;
	    }
	       //if pattern does not matches
	   
		return flag;
		
		
		
	}
	public boolean validatePin(Integer accountPin) {
		boolean flag=false;
		String expression = "^[0-9]{3-4}*$";
		
		CharSequence inputStr = String.valueOf(accountPin);
		Pattern pattern = Pattern.compile(expression);
		Matcher matcher = pattern.matcher(inputStr);
		if(matcher.matches()){
		flag=true;
		}
		return flag;
		}
		

	public boolean validateAccountNumber(Integer accountNumber) {
		boolean flag=false;
		String expression = "^[0-9]{5,10}$";//is numeric
		
		CharSequence inputStr = String.valueOf(accountNumber);
		Pattern pattern = Pattern.compile(expression);
		Matcher matcher = pattern.matcher(inputStr);
		if(matcher.matches()){
		flag=true;
		}
		return flag;
		}
	public boolean validatePhonenumber(String phoneNumber) {
		boolean flag=false;
		String expression = "^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$";
		/*^\\(? : May start with an option "(" .
				(\\d{3}): Followed by 3 digits.
				\\)? : May have an optional ")" 
				[- ]? : May have an optional "-" after the first 3 digits or after optional ) character. 
				(\\d{3}) : Followed by 3 digits. 
				 [- ]? : May have another optional "-" after numeric digits.
				 (\\d{4})$ : ends with four digits.*/
		
		CharSequence inputStr = String.valueOf(phoneNumber);
		Pattern pattern = Pattern.compile(expression);
		Matcher matcher = pattern.matcher(inputStr);
		if(matcher.matches()){
		flag=true;
		}
		return flag;
		
	}
	public boolean validateAddress(String address) {

		boolean flag=false;
		 
	    Pattern pattern = Pattern.compile(new String ("^[#.0-9a-zA-Z\\s,-]+$"));
	    /*^[#.0-9a-zA-Z\s,-]+$
	    E.g. for Address match case

	    #1, North Street, Chennai - 11 
	    E.g. for Address not match case

	    $1, North Street, Chennai @ 11
	*/
	    Matcher matcher = pattern.matcher(address);
	    if(matcher.matches())
	    {
	         flag=true;
	    }
	       //if pattern does not matches
		return flag;
	    



	}
	public boolean validateAge(Customer c) {
		boolean flag = false;
		if(c.getAge()>=18){
			
			flag=true;
			
		}
		
		return flag;
	}
	
	public boolean validateBalance(Customer c){
		boolean flag=false;
		if(c.getBalance()>=500){
			flag=true;
		}
		
		
		
		
		return flag;
		
	}

}
