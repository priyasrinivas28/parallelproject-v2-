package com.capgemini.jpa.tester;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.service.CustomerServiceImpl;

public class BankTester {
	Customer customer=null;
	CustomerServiceImpl serviceImpl=null;

	@Test
	public void testAddNewCustomer() {
		fail("Not yet implemented");
		customer= new Customer();
		serviceImpl=new CustomerServiceImpl();
		customer.setAccountNumber(1069497);
		customer.setAccountPin(8035);
		customer.setAddress("hyderabad");
		customer.setAge(23);
        customer.setBalance(5000.0);
        customer.setEmailId("priya.poka@gmail.com");

	}

	@Test
	public void testShowBalance() {
		fail("Not yet implemented");
		customer= new Customer();
		serviceImpl=new CustomerServiceImpl();
		//Customer cust=serviceImpl.showBalance(1069497,8035);
		//assertEquals(100, balance, 0);
	}

	@Test
	public void testDeposit() {
		fail("Not yet implemented");
	}

	@Test
	public void testWithdraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testFundTransfer() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintTransactions() {
		fail("Not yet implemented");
	}

		 

}
